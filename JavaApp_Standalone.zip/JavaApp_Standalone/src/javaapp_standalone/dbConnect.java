/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapp_standalone;

/**
 *    
 * @author artor
 */
import java.sql.*;  
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Scanner;

public class dbConnect {

    public static void main(String[] args) {

            
    Scanner employee = new Scanner(System.in);  
    Scanner hours = new Scanner(System.in);
    Scanner project = new Scanner(System.in);
    
    DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
    java.sql.Date sqlDate = new java.sql.Date(new java.util.Date().getTime());
    
    System.out.println("Registre su salida del trabajo: ");

    String userName = employee.nextLine();

    System.out.println("Bienvenido " + userName + ": usted ha registrado su hora de salida del dia de hoy " +sqlDate); 
    
    System.out.println("Registre sus horas de trabajo");
    
    String workHours = hours.nextLine();
    
    int workHoras = Integer.parseInt(workHours);	
    
    System.out.println("Registre en que proyecto trabajó el dia de hoy");
    
    String activeProject = project.nextLine();
        
        try{  
        Class.forName("com.mysql.jdbc.Driver");  
        Connection con = DriverManager.getConnection(  
        "jdbc:mysql://localhost:3306/empleados","admin","admin");
        
        // the mysql insert statement
        String query = " insert into empleados (name, workhours, workday, project)"
        + " values (?, ?, ?, ?, ?)"; 
        
        
        Statement stmt = con.createStatement();
        stmt.executeUpdate( "insert into empleados (name, workhours, project)"
        + " values ('"+userName+"', "+workHours+", '"+activeProject+"')");
        
        con.close();
        }
        catch(Exception e){ System.out.println(e);} 
    }
}
